php artisan generate:erd documentation.png


