<img src="{{ asset('images/petitlogo.png') }}" {{ $attributes }} alt="EuroConnect Logo" width="100" height="20">
