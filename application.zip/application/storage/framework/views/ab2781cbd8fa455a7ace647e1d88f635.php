<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <div class="flex items-center gap-4">
                <a href="<?php echo e(route('messages.index')); ?>" class="text-gray-600 dark:text-gray-300 hover:text-indigo-600 transition">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                    </svg>
                </a>
                <div class="flex items-center gap-3">
                    <img src="<?php echo e($user->profile_image ? asset('storage/' . $user->profile_image) : 'https://ui-avatars.com/api/?name=' . urlencode($user->name) . '&background=random'); ?>"
                         alt="<?php echo e($user->name); ?>"
                         class="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-400 dark:ring-indigo-600">
                    <div>
                        <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100">
                            <?php echo e($user->name); ?>

                        </h2>
                        <p class="text-sm text-gray-500 dark:text-gray-400">
                            <?php if($user->followers()->where('follower_id', auth()->id())->exists()): ?>
                                Vous suivez cet utilisateur
                            <?php elseif($user->following()->where('following_id', auth()->id())->exists()): ?>
                                Cet utilisateur vous suit
                            <?php else: ?>
                                Relation mutuelle
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
            <a href="<?php echo e(route('profile.show', $user)); ?>"
               class="text-indigo-600 dark:text-indigo-400 hover:underline text-sm font-medium">
                Voir le profil
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-10">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-md sm:rounded-xl overflow-hidden">
                <div class="p-6">
                    <!-- Messages Area -->
                    <div id="messagesArea" class="space-y-4 mb-6 max-h-[60vh] overflow-y-auto pr-2">
                        <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="flex <?php echo e($message->sender_id === auth()->id() ? 'justify-end' : 'justify-start'); ?>">
                                <div class="flex items-end gap-2 max-w-[75%]">
                                    <?php if($message->sender_id !== auth()->id()): ?>
                                        <img src="<?php echo e($message->sender->profile_image ? asset('storage/' . $message->sender->profile_image) : 'https://ui-avatars.com/api/?name=' . urlencode($message->sender->name) . '&background=random'); ?>"
                                             alt="<?php echo e($message->sender->name); ?>"
                                             class="w-8 h-8 rounded-full object-cover">
                                    <?php endif; ?>
                                    <div class="flex flex-col <?php echo e($message->sender_id === auth()->id() ? 'items-end' : 'items-start'); ?>">
                                        <div class="<?php echo e($message->sender_id === auth()->id() ? 'bg-indigo-600 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-100'); ?> px-4 py-2 rounded-xl shadow-sm">
                                            <p class="text-sm break-words"><?php echo e($message->content); ?></p>
                                        </div>
                                        <span class="text-xs text-gray-500 mt-1">
                                            <?php echo e($message->created_at->format('H:i')); ?>

                                        </span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center py-10 text-gray-500 dark:text-gray-400">
                                Aucun message. Commencez la conversation !
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Message Input -->
                    <form action="<?php echo e(route('messages.store', $user)); ?>" method="POST" class="mt-4">
                        <?php echo csrf_field(); ?>
                        <div class="flex items-center gap-2">
                            <input type="text"
                                   name="content"
                                   placeholder="Écrivez votre message..."
                                   class="flex-1 rounded-lg border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-gray-100 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                   required>
                            <button type="submit"
                                    class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 transition">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                          d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/>
                                </svg>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        const messagesArea = document.getElementById('messagesArea');
        messagesArea.scrollTop = messagesArea.scrollHeight;

        // Auto-refresh messages every 5s
        setInterval(() => {
            fetch(window.location.href)
                .then(response => response.text())
                .then(html => {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(html, 'text/html');
                    const newMessages = doc.querySelector('#messagesArea');
                    if (newMessages) {
                        messagesArea.innerHTML = newMessages.innerHTML;
                        messagesArea.scrollTop = messagesArea.scrollHeight;
                    }
                });
        }, 5000);
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\pc\Desktop\euromedconnect\application\resources\views/messages/show.blade.php ENDPATH**/ ?>