<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['users']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['users']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<!-- Chat Component -->
<div class="fixed right-0 top-0 h-screen flex z-50">
    <!-- Chat Sidebar -->
    <div class="w-80 bg-white shadow-lg transform transition-transform duration-300 ease-in-out translate-x-full" id="chatSidebar">
        <!-- Header -->
        <div class="bg-indigo-600 text-white p-4 flex justify-between items-center">
            <div class="flex items-center space-x-2">
                <h2 class="text-lg font-semibold">Messages</h2>
                <?php
                    $totalUnread = collect($users)->sum('unread_count');
                ?>
                <?php if($totalUnread > 0): ?>
                    <span class="bg-red-500 text-white text-xs rounded-full px-2 py-1">
                        <?php echo e($totalUnread); ?>

                    </span>
                <?php endif; ?>
            </div>
            <button onclick="toggleChatSidebar()" class="text-white hover:text-gray-200">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>

        <!-- Search -->
        <div class="p-4 border-b">
            <div class="relative">
                <input type="text" 
                       id="searchConversations"
                       placeholder="Rechercher une conversation..." 
                       class="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:border-indigo-500">
                <div class="absolute left-3 top-2.5">
                    <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                    </svg>
                </div>
            </div>
        </div>

        <!-- Conversations List -->
        <div class="overflow-y-auto h-[calc(100vh-8rem)]" id="conversationsList">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p-4 border-b hover:bg-gray-50 cursor-pointer transition-colors duration-200" 
                     onclick="openChat(<?php echo e($user['id']); ?>, '<?php echo e($user['name']); ?>', '<?php echo e($user['profile_image'] ? asset('storage/' . $user['profile_image']) : 'https://ui-avatars.com/api/?name=' . urlencode($user['name']) . '&background=random'); ?>')">
                    <div class="flex items-center space-x-3">
                        <div class="relative">
                            <img src="<?php echo e($user['profile_image'] ? asset('storage/' . $user['profile_image']) : 'https://ui-avatars.com/api/?name=' . urlencode($user['name']) . '&background=random'); ?>" 
                                 alt="<?php echo e($user['name']); ?>" 
                                 class="w-12 h-12 rounded-full object-cover">
                            <?php if($user['unread_count'] > 0): ?>
                                <span class="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                                    <?php echo e($user['unread_count']); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-medium text-gray-900 truncate"><?php echo e($user['name']); ?></p>
                            <?php if($user['last_message']): ?>
                                <p class="text-sm text-gray-500 truncate">
                                    <?php echo e($user['last_message']->content); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                        <?php if($user['last_message']): ?>
                            <div class="text-xs text-gray-500">
                                <?php echo e($user['last_message']->created_at->diffForHumans()); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- Chat Window -->
    <div class="w-96 bg-white shadow-lg transform transition-transform duration-300 ease-in-out hidden" id="chatWindow">
        <!-- Chat Header -->
        <div class="bg-indigo-600 text-white p-4 flex justify-between items-center">
            <div class="flex items-center space-x-3">
                <img id="chatUserImage" src="" alt="" class="w-10 h-10 rounded-full object-cover">
                <div>
                    <h3 id="chatUserName" class="text-lg font-semibold"></h3>
                    <p class="text-sm text-indigo-200">En ligne</p>
                </div>
            </div>
            <button onclick="closeChat()" class="text-white hover:text-gray-200">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>

        <!-- Messages Area -->
        <div class="h-[calc(100vh-8rem)] overflow-y-auto p-4 bg-gray-50" id="messagesArea">
            <div class="flex justify-center items-center h-full text-gray-500">
                <p>Sélectionnez une conversation pour commencer</p>
            </div>
        </div>

        <!-- Message Input -->
        <div class="p-4 border-t bg-white">
            <form id="messageForm" class="flex space-x-2">
                <?php echo csrf_field(); ?>
                <input type="text" 
                       id="messageInput"
                       name="message"
                       placeholder="Écrivez votre message..." 
                       class="flex-1 rounded-lg border border-gray-300 focus:outline-none focus:border-indigo-500 px-4 py-2">
                <button type="submit" 
                        class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
                    </svg>
                </button>
            </form>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
let currentUserId = null;
let messageRefreshInterval = null;

function toggleChatSidebar() {
    const sidebar = document.getElementById('chatSidebar');
    sidebar.classList.toggle('translate-x-full');
}

function openChat(userId, userName, userImage) {
    currentUserId = userId;
    const chatWindow = document.getElementById('chatWindow');
    const chatUserName = document.getElementById('chatUserName');
    const chatUserImage = document.getElementById('chatUserImage');
    
    // Update chat header
    chatUserName.textContent = userName;
    chatUserImage.src = userImage;
    
    // Show chat window
    chatWindow.classList.remove('hidden');
    
    // Load messages
    loadMessages(userId);
    
    // Start refreshing messages
    if (messageRefreshInterval) {
        clearInterval(messageRefreshInterval);
    }
    messageRefreshInterval = setInterval(() => loadMessages(userId), 5000);
}

function closeChat() {
    const chatWindow = document.getElementById('chatWindow');
    chatWindow.classList.add('hidden');
    currentUserId = null;
    if (messageRefreshInterval) {
        clearInterval(messageRefreshInterval);
    }
}

function loadMessages(userId) {
    fetch(`/messages/${userId}`)
        .then(response => response.text())
        .then(html => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const messages = doc.querySelector('#messagesArea');
            if (messages) {
                document.getElementById('messagesArea').innerHTML = messages.innerHTML;
                scrollToBottom();
            }
        })
        .catch(error => console.error('Error loading messages:', error));
}

function scrollToBottom() {
    const messagesArea = document.getElementById('messagesArea');
    messagesArea.scrollTop = messagesArea.scrollHeight;
}

// Search functionality
document.getElementById('searchConversations').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const conversations = document.querySelectorAll('#conversationsList > div');
    
    conversations.forEach(conversation => {
        const userName = conversation.querySelector('p').textContent.toLowerCase();
        if (userName.includes(searchTerm)) {
            conversation.style.display = '';
        } else {
            conversation.style.display = 'none';
        }
    });
});

// Message form submission
document.getElementById('messageForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const input = document.getElementById('messageInput');
    const message = input.value.trim();
    
    if (message && currentUserId) {
        const formData = new FormData(this);
        formData.append('_token', document.querySelector('meta[name="csrf-token"]').content);
        
        fetch(`/messages/${currentUserId}`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'Accept': 'text/html'
            },
            body: formData
        })
        .then(response => response.text())
        .then(html => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const messages = doc.querySelector('#messagesArea');
            if (messages) {
                document.getElementById('messagesArea').innerHTML = messages.innerHTML;
                input.value = '';
                scrollToBottom();
            }
        })
        .catch(error => console.error('Error sending message:', error));
    }
});
</script>
<?php $__env->stopPush(); ?> <?php /**PATH C:\Users\pc\Desktop\euromedconnect\application\resources\views/components/chat.blade.php ENDPATH**/ ?>