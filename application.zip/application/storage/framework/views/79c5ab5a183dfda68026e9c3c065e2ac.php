<!-- Chat Window -->
<div class="fixed right-80 top-0 h-screen w-96 bg-white shadow-lg transform transition-transform duration-300 ease-in-out hidden" id="chatWindow">
    <!-- Chat Header -->
    <div class="bg-indigo-600 text-white p-4 flex justify-between items-center">
        <div class="flex items-center space-x-3">
            <img src="<?php echo e($user->profile_image ? asset('storage/' . $user->profile_image) : 'https://ui-avatars.com/api/?name=' . urlencode($user->name) . '&background=random'); ?>" 
                 alt="<?php echo e($user->name); ?>" 
                 class="w-10 h-10 rounded-full object-cover">
            <div>
                <h3 class="text-lg font-semibold"><?php echo e($user->name); ?></h3>
                <p class="text-sm text-indigo-200">En ligne</p>
            </div>
        </div>
        <button onclick="closeChat()" class="text-white hover:text-gray-200">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
        </button>
    </div>

    <!-- Messages Area -->
    <div class="h-[calc(100vh-8rem)] overflow-y-auto p-4" id="messagesArea">
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex <?php echo e($message->sender_id === auth()->id() ? 'justify-end' : 'justify-start'); ?> mb-4">
                <div class="flex <?php echo e($message->sender_id === auth()->id() ? 'flex-row-reverse' : 'flex-row'); ?> items-end space-x-2">
                    <?php if($message->sender_id !== auth()->id()): ?>
                        <img src="<?php echo e($message->sender->profile_image ? asset('storage/' . $message->sender->profile_image) : 'https://ui-avatars.com/api/?name=' . urlencode($message->sender->name) . '&background=random'); ?>" 
                             alt="<?php echo e($message->sender->name); ?>" 
                             class="w-8 h-8 rounded-full object-cover">
                    <?php endif; ?>
                    <div class="max-w-[70%] <?php echo e($message->sender_id === auth()->id() ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-900'); ?> rounded-lg px-4 py-2">
                        <p class="text-sm"><?php echo e($message->content); ?></p>
                        <p class="text-xs <?php echo e($message->sender_id === auth()->id() ? 'text-indigo-200' : 'text-gray-500'); ?> mt-1">
                            <?php echo e($message->created_at->format('H:i')); ?>

                        </p>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Message Input -->
    <div class="p-4 border-t">
        <form id="messageForm" class="flex space-x-2">
            <input type="text" 
                   id="messageInput"
                   placeholder="Écrivez votre message..." 
                   class="flex-1 rounded-lg border border-gray-300 focus:outline-none focus:border-indigo-500 px-4 py-2">
            <button type="submit" 
                    class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
                </svg>
            </button>
        </form>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    // Faire défiler vers le bas automatiquement
    const messagesContainer = document.getElementById('messages-container');
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    // Rafraîchir les messages toutes les 5 secondes
    setInterval(() => {
        fetch(`<?php echo e(route('messages.show', $user)); ?>`)
            .then(response => response.text())
            .then(html => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const newMessages = doc.getElementById('messages-container');
                messagesContainer.innerHTML = newMessages.innerHTML;
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            });
    }, 5000);
</script>
<?php $__env->stopPush(); ?> <?php /**PATH C:\Users\pc\Desktop\euromedconnect\application\resources\views/components/chat-window.blade.php ENDPATH**/ ?>